---
name: youtube
description: |
  YouTube research skill — search videos, fetch metadata, retrieve transcripts, and summarize content.
  Uses YouTube Data API v3 for search/metadata, youtube-transcript-api for transcripts, and yt-dlp as fallback.

  USE FOR:
  - "Search YouTube for X" / "Find top YouTube videos about X"
  - "Get the transcript of [YouTube URL or video ID]"
  - "Summarize this YouTube video: [URL]"
  - "What are the most viewed videos about X?"
  - "Get video metadata / view count / duration for [URL]"
  - "Find recent videos from channel X"
  - Research workflows involving YouTube content

  DO NOT USE FOR:
  - Downloading video files (use yt-dlp directly)
  - Private or age-restricted videos (API won't return transcripts)

user-invocable: true
metadata: {"clawdbot":{"emoji":"📺","requires":{"env":["YOUTUBE_API_KEY"]}}}
---

# YouTube Research Skill

Search YouTube, fetch video metadata, retrieve transcripts, and summarize content for research.

## API Key

The API key is stored in `YOUTUBE_API_KEY` env var (already configured in `~/.openclaw/openclaw.json`).

- Quota: 10,000 units/day free
- Cost: `search.list` = 100 units, `videos.list` = 1 unit, `channels.list` = 1 unit

---

## Method Selection

| Task | Primary Method | Fallback |
|------|---------------|---------|
| Search by keyword | YouTube Data API v3 (`search.list`) | `yt-dlp ytsearch` |
| Get video metadata | YouTube Data API v3 (`videos.list`) | `yt-dlp --dump-json` |
| Get transcript | `youtube-transcript-api` Python lib | `yt-dlp --write-auto-sub` |
| List channel videos | YouTube Data API v3 (`playlistItems.list`) | `yt-dlp` channel URL |

---

## Core Operations

### 1. Search Videos

```python
import urllib.request, json, os

def youtube_search(query, max_results=5, order="viewCount"):
    """
    Search YouTube videos. order options: viewCount, relevance, date, rating
    Returns list of {title, video_id, url, channel, published_at}
    Then use youtube_video_stats() to get view counts.
    """
    key = os.environ.get('YOUTUBE_API_KEY')
    url = (
        f"https://www.googleapis.com/youtube/v3/search"
        f"?part=snippet&q={urllib.parse.quote(query)}"
        f"&type=video&order={order}&maxResults={max_results}&key={key}"
    )
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    
    return [{
        'title': item['snippet']['title'],
        'video_id': item['id']['videoId'],
        'url': f"https://youtube.com/watch?v={item['id']['videoId']}",
        'channel': item['snippet']['channelTitle'],
        'published_at': item['snippet']['publishedAt'],
        'description': item['snippet']['description']
    } for item in data['items']]
```

### 2. Get Video Stats/Metadata

```python
def youtube_video_stats(video_ids):
    """
    Get view counts, duration, likes for a list of video IDs.
    Cost: 1 quota unit (very cheap!). Can batch up to 50 IDs.
    """
    key = os.environ.get('YOUTUBE_API_KEY')
    ids = ','.join(video_ids) if isinstance(video_ids, list) else video_ids
    url = (
        f"https://www.googleapis.com/youtube/v3/videos"
        f"?part=statistics,contentDetails,snippet&id={ids}&key={key}"
    )
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    
    results = []
    for item in data['items']:
        results.append({
            'video_id': item['id'],
            'title': item['snippet']['title'],
            'channel': item['snippet']['channelTitle'],
            'views': int(item['statistics'].get('viewCount', 0)),
            'likes': int(item['statistics'].get('likeCount', 0)),
            'comments': int(item['statistics'].get('commentCount', 0)),
            'duration': item['contentDetails']['duration'],  # ISO 8601: PT4M13S
            'published_at': item['snippet']['publishedAt'],
            'tags': item['snippet'].get('tags', []),
            'url': f"https://youtube.com/watch?v={item['id']}"
        })
    return results
```

### 3. Get Transcript (Primary: youtube-transcript-api)

```python
from youtube_transcript_api import YouTubeTranscriptApi

def get_transcript(video_id_or_url):
    """
    Fetch transcript for a video. ~1-2 seconds.
    Works on any video with auto-generated or manual captions.
    """
    # Extract video ID from URL if needed
    video_id = video_id_or_url
    if 'youtube.com' in video_id_or_url or 'youtu.be' in video_id_or_url:
        import urllib.parse
        parsed = urllib.parse.urlparse(video_id_or_url)
        if 'youtu.be' in video_id_or_url:
            video_id = parsed.path.lstrip('/')
        else:
            video_id = urllib.parse.parse_qs(parsed.query).get('v', [None])[0]
    
    api = YouTubeTranscriptApi()
    transcript = api.fetch(video_id)
    segments = list(transcript)
    
    # Return both plain text and timestamped segments
    plain_text = ' '.join(s.text for s in segments)
    return {
        'video_id': video_id,
        'text': plain_text,
        'segments': [{'start': s.start, 'text': s.text} for s in segments],
        'char_count': len(plain_text)
    }
```

### 4. Get Transcript (Fallback: yt-dlp)

```python
import subprocess, re, os, tempfile

def get_transcript_ytdlp(video_url):
    """
    Fallback transcript fetcher using yt-dlp auto-subtitles.
    Use when youtube-transcript-api fails.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        out_prefix = os.path.join(tmpdir, 'transcript')
        cmd = [
            'yt-dlp',
            '--write-auto-sub', '--sub-lang', 'en',
            '--sub-format', 'srt', '--skip-download',
            '-o', out_prefix, '--quiet', video_url
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        
        srt_file = f"{out_prefix}.en.srt"
        with open(srt_file) as f:
            content = f.read()
        
        # Strip SRT formatting
        clean = re.sub(r'\d+\n\d{2}:\d{2}:\d{2},\d+ --> \d{2}:\d{2}:\d{2},\d+\n', '', content)
        lines = [l.strip() for l in clean.split('\n') if l.strip()]
        # Deduplicate overlapping auto-caption segments
        deduped = []
        for line in lines:
            if not deduped or line != deduped[-1]:
                deduped.append(line)
        return ' '.join(deduped)
```

### 5. Search Without API Key (yt-dlp fallback)

```python
import subprocess, json

def youtube_search_ytdlp(query, max_results=5):
    """No API key needed. Returns title, views, URL, channel."""
    cmd = ['yt-dlp', f'ytsearch{max_results}:{query}', '--dump-json', '--no-download', '--quiet']
    result = subprocess.run(cmd, capture_output=True, text=True)
    videos = []
    for line in result.stdout.splitlines():
        if line.strip().startswith('{'):
            d = json.loads(line)
            videos.append({
                'title': d.get('title'),
                'video_id': d.get('id'),
                'url': f"https://youtube.com/watch?v={d.get('id')}",
                'views': d.get('view_count', 0),
                'channel': d.get('uploader'),
                'duration_secs': d.get('duration'),
                'upload_date': d.get('upload_date'),
            })
    return sorted(videos, key=lambda v: v['views'] or 0, reverse=True)
```

---

## Full Research Workflow

When asked to research a YouTube topic:

1. **Search** with `youtube_search(query, max_results=10, order="relevance")`
2. **Get stats** for all video IDs in one call: `youtube_video_stats([ids...])`
3. **Sort by views** to find most popular
4. **Fetch transcripts** for top 3-5 videos
5. **Summarize** key insights

```python
# Complete research example
import urllib.request, json, os
from youtube_transcript_api import YouTubeTranscriptApi

key = os.environ['YOUTUBE_API_KEY']
query = "obsidian note taking"

# Step 1: Search (100 quota units)
search_url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&q={urllib.parse.quote(query)}&type=video&order=relevance&maxResults=10&key={key}"
with urllib.request.urlopen(search_url) as r:
    search_results = json.loads(r.read())

ids = [item['id']['videoId'] for item in search_results['items']]

# Step 2: Get stats (1 quota unit for all 10)
stats_url = f"https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails,snippet&id={','.join(ids)}&key={key}"
with urllib.request.urlopen(stats_url) as r:
    stats_results = json.loads(r.read())

# Step 3: Sort by views
videos = sorted(stats_results['items'], key=lambda x: int(x['statistics'].get('viewCount', 0)), reverse=True)

# Step 4: Print results
for v in videos[:5]:
    print(f"{int(v['statistics']['viewCount']):>10,} views | {v['snippet']['title']}")
    print(f"  https://youtube.com/watch?v={v['id']}")

# Step 5: Fetch transcript for #1
top_id = videos[0]['id']
api = YouTubeTranscriptApi()
transcript = api.fetch(top_id)
text = ' '.join(s.text for s in transcript)
print(f"\nTranscript ({len(text)} chars): {text[:500]}...")
```

---

## CLI Quick Reference

```bash
# Search (no API key needed)
yt-dlp "ytsearch10:TOPIC" --dump-json --no-download --quiet | \
  python3 -c "import sys,json; [print(f\"{json.loads(l)['view_count']:>10,} | {json.loads(l)['title']}\") for l in sys.stdin if l.strip().startswith('{')]"

# Get transcript via python
python3 -c "
from youtube_transcript_api import YouTubeTranscriptApi
api = YouTubeTranscriptApi()
t = api.fetch('VIDEO_ID')
print(' '.join(s.text for s in t))
"

# Full metadata dump
yt-dlp --dump-json --no-download "https://youtube.com/watch?v=VIDEO_ID" | python3 -m json.tool
```

---

## Quota Management

- **10,000 units/day** free (resets midnight Pacific)
- `search.list` = 100 units → max ~100 searches/day
- `videos.list` = 1 unit → effectively unlimited metadata lookups
- **Strategy**: Use `search` once, then batch `videos` lookups for all results
- **If quota exhausted**: Fall back to `yt-dlp ytsearch` (no API key, no quota)

---

## Installation Status

| Component | Status | Location |
|-----------|--------|----------|
| `yt-dlp` | ✅ Installed (2026.03.03) | `/opt/homebrew/bin/yt-dlp` |
| `youtube-transcript-api` | ✅ Installed | Python env |
| `YOUTUBE_API_KEY` | ✅ Configured | `~/.openclaw/openclaw.json` |
| YouTube Data API v3 | ✅ Active | Google Cloud |
